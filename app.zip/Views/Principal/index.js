import React from 'react';
import { StyleSheet, Text, View, TextInput, KeyboardAvoidingView  } from 'react-native';
import { Image, Button, Header } from 'react-native-elements';
// import { Container } from './styles';

export default class Principal extends React.Component {

    static navigationOptions = {
        header: null,
      };

    render(){
        return (
            <>
            <View style={styles.container}>
                
                <Text>Nada</Text>
            </View>
            </>
        );
    }
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#FFF',
      alignItems: 'center',
      justifyContent: 'center',
    },
  });